// Content script for Moodle Gemini Search Extension
// Provides Ctrl+G functionality to get AI assistance on any page

console.log('🔵 Moodle Gemini Search content script loaded on:', window.location.href);
console.log('🔵 Extension is working - try Ctrl+G to test!');

// Global variables
let isProcessingRequest = false;
let currentPopup = null;

// Function to display error message
function displayError(message) {
  console.error('🔴 Error:', message);
  
  // Remove existing popup if any
  if (currentPopup) {
    currentPopup.remove();
    currentPopup = null;
  }
  
  // Create error popup
  const popup = document.createElement('div');
  popup.id = 'gemini-search-popup';
  popup.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    width: 400px;
    max-height: 500px;
    background: #ff4444;
    color: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    z-index: 10000;
    font-family: Arial, sans-serif;
    font-size: 14px;
    line-height: 1.4;
    border: 2px solid #ff6666;
  `;
  
  popup.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
      <strong>❌ Error</strong>
      <button onclick="this.parentElement.parentElement.remove()" style="background: none; border: none; color: white; font-size: 18px; cursor: pointer;">×</button>
    </div>
    <div>${message}</div>
  `;
  
  document.body.appendChild(popup);
  currentPopup = popup;
  
  // Auto-remove after 10 seconds
  setTimeout(() => {
    if (popup.parentNode) {
      popup.remove();
    }
  }, 10000);
}

// Function to display loading popup
function displayLoading() {
  // Remove existing popup if any
  if (currentPopup) {
    currentPopup.remove();
    currentPopup = null;
  }
  
  const popup = document.createElement('div');
  popup.id = 'gemini-search-popup';
  popup.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    width: 400px;
    background: #2196F3;
    color: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    z-index: 10000;
    font-family: Arial, sans-serif;
    font-size: 14px;
    line-height: 1.4;
  `;
  
  popup.innerHTML = `
    <div style="display: flex; align-items: center; margin-bottom: 10px;">
      <div style="width: 20px; height: 20px; border: 2px solid #fff; border-top: 2px solid transparent; border-radius: 50%; animation: spin 1s linear infinite; margin-right: 10px;"></div>
      <strong>🤖 Analyzing with Gemini...</strong>
    </div>
    <div>Processing page content and images...</div>
    <style>
      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
    </style>
  `;
  
  document.body.appendChild(popup);
  currentPopup = popup;
}

// Function to display AI response
function displayResponse(response, model) {
  // Remove existing popup if any
  if (currentPopup) {
    currentPopup.remove();
    currentPopup = null;
  }
  
  const popup = document.createElement('div');
  popup.id = 'gemini-search-popup';
  popup.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    width: 500px;
    max-height: 600px;
    background: #4CAF50;
    color: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    z-index: 10000;
    font-family: Arial, sans-serif;
    font-size: 14px;
    line-height: 1.5;
    overflow-y: auto;
    border: 2px solid #66BB6A;
  `;
  
  popup.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
      <div style="display: flex; align-items: center;">
        <span style="font-size: 20px; margin-right: 8px;">🤖</span>
        <strong>Gemini Response</strong>
        <span style="margin-left: 10px; font-size: 12px; opacity: 0.8;">(${model})</span>
      </div>
      <button onclick="this.parentElement.parentElement.remove()" style="background: none; border: none; color: white; font-size: 18px; cursor: pointer;">×</button>
    </div>
    <div style="background: rgba(255,255,255,0.1); padding: 15px; border-radius: 5px; white-space: pre-wrap;">${response}</div>
    <div style="margin-top: 15px; font-size: 12px; opacity: 0.8; text-align: center;">
      Press Ctrl+G again to ask another question
    </div>
  `;
  
  document.body.appendChild(popup);
  currentPopup = popup;
  
  // Make popup draggable
  let isDragging = false;
  let startX, startY, startY;
  
  const header = popup.querySelector('div');
  header.style.cursor = 'move';
  
  header.addEventListener('mousedown', (e) => {
    isDragging = true;
    startX = e.clientX - popup.offsetLeft;
    startY = e.clientY - popup.offsetTop;
    e.preventDefault();
  });
  
  document.addEventListener('mousemove', (e) => {
    if (isDragging) {
      popup.style.left = (e.clientX - startX) + 'px';
      popup.style.top = (e.clientY - startY) + 'px';
      popup.style.right = 'auto';
    }
  });
  
  document.addEventListener('mouseup', () => {
    isDragging = false;
  });
}

// Function to get page content
function getPageContent() {
  // Get selected text if any
  const selectedText = window.getSelection().toString().trim();
  
  if (selectedText) {
    console.log('Using selected text:', selectedText);
    return selectedText;
  }
  
  // Get page content
  const content = document.body.innerText || document.body.textContent || '';
  console.log('Using page content, length:', content.length);
  
  // Limit content length to avoid API limits
  if (content.length > 8000) {
    return content.substring(0, 8000) + '... [content truncated]';
  }
  
  return content;
}

// Function to get page images
async function getPageImages() {
  const images = [];
  const imgElements = document.querySelectorAll('img');
  
  for (const img of imgElements) {
    try {
      // Skip if image is too small or is a data URL
      if (img.width < 50 || img.height < 50 || img.src.startsWith('data:')) {
        continue;
      }
      
      // Convert image to base64
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = Math.min(img.width, 800);
      canvas.height = Math.min(img.height, 600);
      
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      const dataURL = canvas.toDataURL('image/jpeg', 0.8);
      
      images.push({
        data: dataURL.split(',')[1],
        mimeType: 'image/jpeg'
      });
      
      // Limit to 3 images to avoid API limits
      if (images.length >= 3) break;
    } catch (error) {
      console.warn('Error processing image:', error);
    }
  }
  
  return images;
}

// Main function to handle AI request
async function handleAIRequest() {
  console.log('=== handleAIRequest CALLED ===');
  
  // Prevent duplicate requests
  if (isProcessingRequest) {
    console.log('Request already in progress, ignoring duplicate');
    return;
  }
  
  isProcessingRequest = true;
  
  try {
    // Show loading popup
    displayLoading();
    
    // Get page content and images
    const content = getPageContent();
    const images = await getPageImages();
    
    console.log('Content length:', content.length);
    console.log('Images found:', images.length);
    
    // Send to background script
    const response = await chrome.runtime.sendMessage({
      type: 'ANALYZE_CONTENT',
      data: {
        content: content,
        images: images,
        pageUrl: window.location.href
      }
    });
    
    if (response.error) {
      displayError(response.error);
    } else if (response.success) {
      displayResponse(response.response, response.model);
    } else {
      displayError('Unknown error occurred');
    }
    
  } catch (error) {
    console.error('Error in handleAIRequest:', error);
    displayError('Failed to process request: ' + error.message);
  } finally {
    isProcessingRequest = false;
  }
}

// Universal Ctrl+G listener (capture phase to intercept before Chrome)
document.addEventListener('keydown', async (e) => {
  console.log('🔵 Key pressed:', e.key, 'Ctrl:', e.ctrlKey, 'Shift:', e.shiftKey);
  
  if (e.ctrlKey && !e.shiftKey && (e.key === 'G' || e.key === 'g')) {
    console.log('🔵 Ctrl+G detected - preventing default IMMEDIATELY');
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    
    console.log('🔵 Calling handleAIRequest');
    try {
      await handleAIRequest();
    } catch (error) {
      console.error('🔴 Error in handleAIRequest:', error);
      displayError('Error processing request: ' + error.message);
    }
    return false;
  }
}, true); // TRUE = capture phase (intercept before Chrome handlers)

// Also add a more aggressive keydown listener
window.addEventListener('keydown', async (e) => {
  if (e.ctrlKey && !e.shiftKey && (e.key === 'G' || e.key === 'g')) {
    console.log('🔵 Window Ctrl+G detected - preventing default');
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    
    console.log('🔵 Calling handleAIRequest from window listener');
    try {
      await handleAIRequest();
    } catch (error) {
      console.error('🔴 Error in handleAIRequest from window:', error);
      displayError('Error processing request: ' + error.message);
    }
    return false;
  }
}, true);

// Additional aggressive blocking for Chrome's search functionality
document.addEventListener('keydown', (e) => {
  if (e.ctrlKey && !e.shiftKey && (e.key === 'G' || e.key === 'g')) {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    return false;
  }
}, true);

// Block keyup events as well
document.addEventListener('keyup', (e) => {
  if (e.ctrlKey && !e.shiftKey && (e.key === 'G' || e.key === 'g')) {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    return false;
  }
}, true);

// Override Chrome's default keyboard shortcuts
document.addEventListener('keydown', (e) => {
  if (e.ctrlKey && !e.shiftKey && (e.key === 'G' || e.key === 'g')) {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    return false;
  }
}, true);

// Block the specific Chrome search shortcut
document.addEventListener('keydown', (e) => {
  if (e.ctrlKey && !e.shiftKey && e.key === 'G') {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    return false;
  }
}, true);

// Override document-level keyboard handling
document.onkeydown = function(e) {
  if (e.ctrlKey && !e.shiftKey && (e.key === 'G' || e.key === 'g')) {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    return false;
  }
};

// Override window-level keyboard handling
window.onkeydown = function(e) {
  if (e.ctrlKey && !e.shiftKey && (e.key === 'G' || e.key === 'g')) {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    return false;
  }
};

// Block Chrome's default search behavior more aggressively
document.addEventListener('keydown', function(e) {
  if (e.ctrlKey && !e.shiftKey && (e.key === 'G' || e.key === 'g')) {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    e.returnValue = false;
    return false;
  }
}, true);

// Additional blocking for Chrome's search dialog
document.addEventListener('keydown', function(e) {
  if (e.ctrlKey && !e.shiftKey && e.key === 'G') {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    e.returnValue = false;
    return false;
  }
}, true);

console.log('Moodle Gemini Search content script initialized');
